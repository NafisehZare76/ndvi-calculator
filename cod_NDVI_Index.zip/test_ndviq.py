import tifffile as tiff
from calculate_ndvi import calculate_ndvi

img=tiff.imread('3_agri_img.tif')
ndvi=calculate_ndvi(img)
export_img=tiff.imwrite('ndvich.tif',ndvi)
