import numpy as np

def calculate_ndvi(img_stack):
    """
    calculate NDVI iNDEX

    Parameters:
    img_stack : numpy.ndarray
        input :3d
    
    export:
    numpy.ndarray
       export 2d
    """
    if not isinstance(img_stack, np.ndarray):
        raise TypeError("numpy aray is 2d")
    if img_stack.shape[0] < 4:
        raise ValueError("image is <=4 bands")

    ndvi = (img_stack[3, :, :] - img_stack[2, :, :]) / (img_stack[3, :, :] + img_stack[2, :, :])
    return ndvi
